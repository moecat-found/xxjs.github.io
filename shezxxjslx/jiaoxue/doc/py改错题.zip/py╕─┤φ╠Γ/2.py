m=input()
m=float()   #m=float(input())
cm=m*100
print("相对应的厘米数为：",cm)   
