m=input(eval())      #eval和input函数互换
cm=m*100
print("相对应的厘米数为：",cm)
