n=int(input())
n1=n//10
n2=n%10
print(n1 n2)   #输出格式错误  (n1, n2)
