n=eval(input()   #输入格式错误，括号成对出现
zong=10*n
print(zong)
