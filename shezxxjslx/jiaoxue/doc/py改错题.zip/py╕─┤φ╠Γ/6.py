m=int(input)   #m,n输入格式错误int(input())
n=int(input)
rs=280/m/n
print('%.0f'%rs)
