n=input()           #需要定义n类型
money=n+80
print(money)
