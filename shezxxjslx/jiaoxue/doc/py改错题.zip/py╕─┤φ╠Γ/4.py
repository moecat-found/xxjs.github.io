r=eval(input())
area=10*10-3.14*r*2      #公式错误   r**2
x=int(area*100+0.5)/100  #用来解决Python中的5舍6入问题
print('%.2f'%x)
