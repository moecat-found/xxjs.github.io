n=eval(input())
c=(200+120)*2n         #公式书写错误2*n
print(c)

